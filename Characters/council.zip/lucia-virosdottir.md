# Mother-Abbot Lucia Virosdottir

**Seat:** Temple Authority &nbsp;|&nbsp; **Office:** Current Council Chair &nbsp;|&nbsp; **Race:** Human &nbsp;|&nbsp; **Age:** Early 70s &nbsp;|&nbsp; *"Some evils require steel and spell as much as prayer."*

<!-- TODO: portrait — supply a filename to add -->

> *"This is beyond our usual ministrations."*

Temple Authority on the Autumn Council, its current Chair, and Mother-Abbot of the Abbey of Saint Viro. In her early seventies, slight but commanding, with forty years of service behind her and family roots reaching back to the city's founders. Wise and compassionate, and visibly wearied by a crisis that strains her faith.

---

## On the Council
She offers the city sanctuary, care for the afflicted, and the Abbey's scholarship — while being honest that prayer alone won't answer what's happening. As Chair she holds the chamber together, even as she comes to suspect that some of what's coming will demand steel and spell as much as devotion.

---

## Connections
- **[The Autumn Council](/en/Venturia/Government/autumn-council)** — Temple Authority seat; current Council Chair.
- **[The Abbey of Saint Viro and the Faithful](/en/Venturia/Factions/abbey-of-saint-viro)** — She leads the Abbey as Mother-Abbot.
- **St. Viro's Respite** — The Respite operates under the Abbey's oversight.
