# Master Artisan Celeste Orion

**Seat:** Guild-Master &nbsp;|&nbsp; **Guild:** Binding Crafts Guild &nbsp;|&nbsp; **Race:** Human &nbsp;|&nbsp; **Age:** Mid-50s &nbsp;|&nbsp; *"My people are the ones disappearing."*

<!-- TODO: portrait — supply a filename to add -->

> *"We need protection now."*

Guild-Master on the Autumn Council and head of the Binding Crafts Guild — the carpenters, masons, shipwrights, and construction trades. Mid-fifties, with calloused hands and ink-stained fingers, the daughter of a Liminal House foundling who built her career from nothing and remains fiercely protective of working people.

---

## On the Council
The chamber's loudest voice for the city's laborers. With the disappearances falling hardest on the working districts, she pushes for concrete protection: more Watch patrols where people actually work, hazard pay near the fog line, and compensation for the families of the missing.

---

## Connections
- **[The Autumn Council](/en/Venturia/Government/autumn-council)** — Holds one of the two Guild-Master seats.
- **The Binding Crafts Guild** — The building trades she leads.
- **[Liminal House](/en/Venturia/Factions/liminal-house)** — Her parent was a Liminal House foundling.
