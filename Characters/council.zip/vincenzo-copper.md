# Guildmaster Vincenzo Copper

**Seat:** Guild-Master &nbsp;|&nbsp; **Guild:** Metals Guild &nbsp;|&nbsp; **Race:** Dwarf &nbsp;|&nbsp; *"Rush produces shoddy work."*

<!-- TODO: portrait — supply a filename to add -->

> *"We'll survive this by doing what we've always done."*

Guild-Master on the Autumn Council, representing the Metals Guild — smiths, metalworkers, jewelers, and the Mirrorwrights. A conservative dwarf traditionalist whose family has led the guild for three generations, he takes the seven-generation view of every problem: wise and steadying, and maddeningly slow to act.

---

## On the Council
The voice of caution and continuity. Vincenzo trusts the guilds' long survival over panic and resists rushing into emergency measures or sweeping new laws. He sees wealth as a responsibility and standards as the thing that outlasts every crisis.

---

## Connections
- **[The Autumn Council](/en/Venturia/Government/autumn-council)** — Holds one of the two Guild-Master seats.
- **The Metals Guild** — The smiths, jewelers, and Mirrorwrights under his leadership.
