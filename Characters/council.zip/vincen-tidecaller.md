# Vincen Tidecaller

**Seat:** Master of the Tidekeeper's Lodge &nbsp;|&nbsp; **Race:** Human &nbsp;|&nbsp; **Age:** 60s &nbsp;|&nbsp; *"It's older than your warehouses and your trade routes."*

<!-- TODO: portrait — supply a filename to add -->

> *"The fog moves wrong. Something's waking that was sleeping."*

Master of the Tidekeeper's Lodge, holding his Autumn Council seat by ancient charter rather than wealth. A quiet man in his sixties with a permanent horizon-squint, he speaks rarely and is listened to when he does, carrying generations of accumulated Tidekeeper knowledge. He cares more for the Lodge's independence than for politics.

---

## On the Council
A voice for caution rooted in long memory. Vincen warns that the strangeness in the water and fog is far older than the city's commerce, and should be understood before it is acted upon — not a problem to be solved with money. He came to the council as a compromise candidate after the two Harbor-Lords deadlocked.

---

## Connections
- **[The Autumn Council](/en/Venturia/Government/autumn-council)** — Master of the Tidekeeper's Lodge; the compromise appointment after the Teodor–Constanza deadlock.
- **The Tidekeeper's Lodge** — The order he leads.
