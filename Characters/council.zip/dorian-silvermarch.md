# Archmagister Dorian Silvermarch

**Seat:** Archmagister of VAVA &nbsp;|&nbsp; **Race:** High elf &nbsp;|&nbsp; **Age:** ~2 centuries &nbsp;|&nbsp; *"A matter for the Watch and the Abbey."*

<!-- TODO: portrait — supply a filename to add -->

> *"These manifestations are a security matter and a spiritual one."*

Archmagister of the Venturian Academy of Veiled Arts and an Autumn Council member. A high elf nearing two centuries — middle-aged by elven reckoning — he has taught at VAVA for close to a hundred years and led it for forty, a rare scholar who is both genuinely brilliant and genuinely liked, able to make obscure magical theory feel alive.

---

## On the Council
Dorian votes with cautious pragmatism, favoring measured investigation and opposing anything that might destabilize the city — or the Academy's funding. His public line is that the manifestations belong to the Watch and the Abbey; in practice he keeps VAVA's considerable scholarship in careful reserve.

---

## Connections
- **[The Autumn Council](/en/Venturia/Government/autumn-council)** — Archmagister's seat.
- **[The Venturian Academy of Veiled Arts](/en/Venturia/Factions/vava)** — Academy leader and keeper of its archives.
