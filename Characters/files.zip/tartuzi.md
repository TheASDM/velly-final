<!-- DM NOTE (not rendered): ⚠ CAMPAIGN-CRITICAL. Tartuzi is the sphinx bound as the eternal lock of the Keeper's prison and Kryton's true patron. NONE of that is public. This page is a deliberate near-empty placeholder. Consider keeping it DM-only. -->
# Tartuzi

**Type:** Legendary — a sphinx &nbsp;|&nbsp; *"A riddle with a name."*

A name out of old lore: a sphinx, of the kind that keep riddles and deep truths in the oldest stories. Beyond the name, the public record holds essentially nothing.

---

## In Lore
<!-- TODO: ⚠ The knowledge base contains NO public-facing material for Tartuzi — everything substantive is campaign-secret. This is a deliberate placeholder. Supply the in-world legend you want public, or pull this page and keep Tartuzi DM-only. -->
