# Aurelio Volante

**Role:** Mask collector & merchant &nbsp;|&nbsp; **Trade:** Volante &amp; Associates, the Market Tiers &nbsp;|&nbsp; *"Collects masks, and stories."*

<!-- TODO: portrait — supply a filename to add -->

A well-traveled merchant and inveterate collector who keeps a modest spice-and-dye house in the Market Tiers and a far less modest collection of masks. Tall, olive-skinned, somewhere in his fifties, with the easy bearing of a man who has been comfortable in difficult rooms his whole life.

---

## The Trade
His business, Volante &amp; Associates, deals in spice and dye out of the Market Tiers — legitimate, profitable, and quiet. His real passion lies elsewhere: a narrow room in his warehouse hung with fifty masks and more, gathered from a dozen craft traditions across his travels.

---

## Manner
Warm, curious, lightly theatrical, with a dry humor he delivers without a flicker. He has learned that silence makes people fill the space in interesting ways, and he uses it. He collects masks, information, and interesting people in roughly equal measure.

---

## Connections
- **The Masquers' Sodality** — Connected to the Sodality through his collecting and trade.
