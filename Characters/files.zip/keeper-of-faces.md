<!-- DM NOTE (not rendered): ⚠ CAMPAIGN-CRITICAL. The Keeper of Faces is the imprisoned Archfey at the heart of the campaign (Lotan's true patron; the prison in Vallombrosa). NONE of that is public. This page is a deliberate folklore-only placeholder. Do NOT connect it to Vallombrosa, Lotan, Silas, Tartuzi, or any prison. Consider keeping it DM-only. -->
# The Keeper of Faces

**Type:** Masquerade folklore &nbsp;|&nbsp; *"A patron of borrowed faces."*

A name that drifts through the city's mask-culture — invoked, half in earnest, around the Autumn Masquerade and in the workshops of the Masquers' Sodality. In the folklore, the Keeper of Faces is a patron of masks and chosen faces: the old notion that the face you put on may be truer than the one you were born with.

---

## In Folklore
<!-- TODO: ⚠ The knowledge base contains NO public-facing legend for the Keeper of Faces — everything substantive is campaign-secret. The framing above is the safest plausible public read (masquerade folklore tied to the city's mask culture) and is the most this page can safely say. Supply the in-world legend you want players able to find, or pull this page and keep the Keeper DM-only. -->
