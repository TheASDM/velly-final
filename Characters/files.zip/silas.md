# Silas

**Status:** Comatose — St. Viro's Respite &nbsp;|&nbsp; **First seen:** The night Marcus vanished &nbsp;|&nbsp; *"The scarred stranger."*

<!-- TODO: portrait — supply a filename to add -->

A man no one can name, brought to St. Viro's Respite after he appeared at the fog line the same night the Fog Warden Marcus disappeared. He has not woken since. For lack of anything else to call him, the staff call him the scarred patient.

---

## Description
He lies comatose under Orabella's care. His body is covered in strange scars — not the ragged marks of any wound the healers recognize, but deliberate patterns, almost ordered enough to read. On close examination they carry a faint charge, like the air before lightning. Now and then he makes a sound, as though something in him sits closer to the surface than his stillness suggests.

---

## What's Known
Next to nothing. He arrived with no belongings, no papers, and no one to claim him — appearing at the Overlook's fog line on the night Marcus failed to return. The two events have been spoken of together ever since.

---

## Connections
- **[Orabella](/en/Venturia/Characters-PCs/orabella)** — His caretaker at St. Viro's Respite, and the one studying his scars.
- **[Marcus](/en/Venturia/Characters-NPCs/marcus)** — Disappeared the same night Silas appeared at the fog line.
